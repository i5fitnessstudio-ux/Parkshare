import 'package:parkshare_backend/database/db.dart';
import 'package:parkshare_backend/middleware/middleware.dart';
import 'package:parkshare_backend/services/parking_service.dart';
import 'package:postgres/postgres.dart';

/// Settlement states for one owner earning (`payment_transfers`).
class SettlementStatus {
  SettlementStatus._();
  static const String pending = 'PENDING';
  static const String settled = 'SETTLED';

  /// True when a status means "already paid out to the owner".
  static bool isSettled(String? status) =>
      (status ?? '').trim().toUpperCase() == settled;
}

/// Manual (out-of-band) owner settlement.
///
/// Razorpay Route is NOT activated, so ParkShare cannot move an owner's share
/// through Razorpay. Until Route is live an administrator pays the owner
/// outside Razorpay and records that payout here.
///
/// This service ONLY flips the already-existing `payment_transfers` ledger row
/// from PENDING to SETTLED (plus audit fields). It is a hard boundary:
///   * it never calls Razorpay and never enables Route;
///   * it never writes `razorpay_transfer_id` (that column stays NULL for a
///     manual payout — a manual payout is NOT a Razorpay transfer);
///   * it determines the owner from the ledger row itself, never from input;
///   * it is idempotent — one earning can be settled at most once, and a
///     repeat call returns the existing record without changing anything.
class AdminSettlementService {
  /// Marks one owner earning as settled.
  ///
  /// [transferId] is the `payment_transfers.id`. [adminUserId] must be the
  /// authenticated admin's id (from the verified JWT) — it is recorded for
  /// audit and is never used to decide WHICH owner is paid.
  ///
  /// [reference] is an optional external payout reference (UTR / bank ref) and
  /// [note] an optional free-text note. `settledAt` is generated server-side.
  Future<Map<String, dynamic>> markSettled({
    required String transferId,
    required String adminUserId,
    String reference = '',
    String note = '',
  }) async {
    // Validation happens BEFORE any database work, so a malformed request can
    // never reach a query (and is cheaply unit-testable).
    if (!ParkingService.isUuid(transferId)) {
      throw ApiError.validation('A valid settlement id is required.');
    }
    if (!ParkingService.isUuid(adminUserId)) {
      throw ApiError.unauthorized('A valid admin identity is required.');
    }
    final ref = reference.trim();
    final cleanNote = note.trim();
    if (ref.length > 120) {
      throw ApiError.validation(
        'Manual payout reference is too long (max 120 characters).',
      );
    }
    if (cleanNote.length > 500) {
      throw ApiError.validation('Note is too long (max 500 characters).');
    }

    return Db.pool.withConnection((conn) async {
      return conn.runTx((tx) async {
        // Lock the ledger row for the duration of the settlement so two admins
        // cannot settle the same earning twice.
        final current = await tx.execute(
          Sql.named('''
          SELECT id, owner_id, booking_id, settlement_status, owner_amount_paise,
                 settled_at, manual_payout_reference, manual_payout_note
          FROM payment_transfers
          WHERE id = @id
          FOR UPDATE
          '''),
          parameters: {'id': transferId},
        );
        if (current.isEmpty) {
          throw ApiError.notFound('Settlement record not found.');
        }
        final row = current.first.toColumnMap();

        // Idempotency: an already-settled earning is returned untouched. We do
        // NOT overwrite the original payout reference/note/settled_at.
        if (SettlementStatus.isSettled(row['settlement_status']?.toString())) {
          return _view(row, alreadySettled: true);
        }

        final updated = await tx.execute(
          Sql.named('''
          UPDATE payment_transfers
          SET settlement_status = 'SETTLED',
              settled_at = NOW(),
              settled_by_admin_user_id = @admin,
              manual_payout_reference = NULLIF(@ref, ''),
              manual_payout_note = NULLIF(@note, ''),
              updated_at = NOW()
          WHERE id = @id
            AND settlement_status <> 'SETTLED'
          RETURNING id, owner_id, booking_id, settlement_status,
                    owner_amount_paise, settled_at, manual_payout_reference,
                    manual_payout_note
          '''),
          parameters: {
            'id': transferId,
            'admin': adminUserId,
            'ref': ref,
            'note': cleanNote,
          },
        );
        if (updated.isEmpty) {
          // Lost a race: somebody settled it between the SELECT and UPDATE.
          // Re-read and answer idempotently.
          final reread = await tx.execute(
            Sql.named('''
            SELECT id, owner_id, booking_id, settlement_status,
                   owner_amount_paise, settled_at, manual_payout_reference,
                   manual_payout_note
            FROM payment_transfers
            WHERE id = @id
            '''),
            parameters: {'id': transferId},
          );
          return _view(reread.first.toColumnMap(), alreadySettled: true);
        }
        return _view(updated.first.toColumnMap(), alreadySettled: false);
      });
    });
  }

  /// Owner-facing-safe view of one settlement row. No Admin/PII leakage; the
  /// owner id is included only so the caller can log which owner was credited.
  static Map<String, dynamic> _view(
    Map<String, dynamic> row, {
    required bool alreadySettled,
  }) {
    return {
      'paymentTransferId': row['id'].toString(),
      'ownerId': row['owner_id']?.toString(),
      'bookingId': row['booking_id']?.toString(),
      'settlementStatus':
          (row['settlement_status']?.toString() ?? SettlementStatus.pending)
              .toUpperCase(),
      'ownerAmountPaise': _intOr(row['owner_amount_paise'], 0),
      'settledAt': row['settled_at']?.toString(),
      'manualPayoutReference': row['manual_payout_reference']?.toString(),
      'alreadySettled': alreadySettled,
    };
  }

  static int _intOr(Object? value, int fallback) =>
      value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
}
