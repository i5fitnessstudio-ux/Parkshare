import 'package:parkshare_backend/middleware/auth_middleware.dart';
import 'package:parkshare_backend/middleware/middleware.dart';
import 'package:parkshare_backend/models/user.dart';
import 'package:parkshare_backend/services/admin_settlement_service.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

/// Back-office (admin-only) routes. No Flutter surface reaches these.
///
///   POST /api/admin/settlements/{paymentTransferId}/mark-settled
///
/// AUTHORITY: the acting admin id comes from the verified JWT only
/// ([requireUserIdOfRole] with role `admin`). The owner being paid is derived
/// by the service from the `payment_transfers` row itself — the request body
/// can neither name an owner nor a payout amount.
///
/// This is the TEMPORARY manual settlement path used while Razorpay Route is
/// not activated. It records a payout ParkShare already made outside Razorpay;
/// it never calls Razorpay and never creates a transfer id.
class AdminRoutes {
  final AdminSettlementService _settlements = AdminSettlementService();

  Handler get handler {
    final router = Router(
      notFoundHandler: (Request req) {
        return ApiResponse.notFound('Admin route not found.');
      },
    );

    // Mark one owner earning as settled after a real, out-of-band payout.
    // `{paymentTransferId}` is the `payment_transfers.id`.
    router.post('/settlements/<paymentTransferId>/mark-settled', (
      Request req,
      String paymentTransferId,
    ) async {
      final adminId = await requireUserIdOfRole(
        req,
        allowedRoles: [UserRole.admin],
      );
      final body = await readJsonBody(req) ?? {};
      final payload = await _settlements.markSettled(
        transferId: paymentTransferId,
        adminUserId: adminId,
        reference:
            body['manualPayoutReference']?.toString() ??
            body['reference']?.toString() ??
            '',
        note: body['note']?.toString() ?? '',
      );
      final already = payload['alreadySettled'] == true;
      return ApiResponse.ok(
        payload,
        already
            ? 'Settlement was already recorded; no change made.'
            : 'Settlement marked as settled.',
      );
    });

    return router.call;
  }
}
