// ignore_for_file: avoid_print
import 'dart:io' show Platform;

import 'package:dotenv/dotenv.dart';

/// Central application configuration loaded from the `.env` file
/// and process environment variables. Secrets are never hard-coded.
///
/// SECURITY (audit H-01 / H-02 / M-01 / M-16):
/// * [jwtSecret] no longer falls back to a *usable* secret when the
///   environment is `production`. In production a missing/weak
///   `JWT_SECRET` makes [validateForStartup] fail and `bin/server.dart`
///   exits BEFORE binding the socket, so a deployment can never silently
///   sign tokens with a key published in this repository.
/// * [allowDevOtp] defaults to `false`. The password-reset OTP is never
///   printed and never returned in an API response unless this is
///   explicitly switched on, and switching it on is refused in production.
class Config {
  Config._();

  static final DotEnv _env = DotEnv(includePlatformEnvironment: true)..load();

  /// The dev-only signing key. It is published in this repository, so it is
  /// usable ONLY while [isDevelopment] is true and is rejected outright by
  /// [validateForStartup] in production.
  static const String devJwtSecret = 'dev-only-insecure-secret-change-me';

  /// Minimum length accepted for a production JWT secret (256 bits of entropy
  /// at minimum once base64/hex encoded).
  static const int minJwtSecretLength = 32;

  // ---------------------------------------------------------------------
  // Environment
  // ---------------------------------------------------------------------

  /// `APP_ENV` — `production` (default in hosted deployments) or anything
  /// else for development. Read with `_env` so `DotEnv(includePlatformEnvironment:
  /// true)` lets a platform variable override the `.env` file.
  static String get appEnv => (_env['APP_ENV'] ?? 'development').trim();

  static bool get isProduction => appEnv.toLowerCase() == 'production';
  static bool get isDevelopment => !isProduction;

  /// When false (the default) the server prints no per-request access log and
  /// never dumps a stack trace: request/OTP logging is an audit trail.
  static bool get requestLoggingEnabled =>
      !isProduction || _bool('LOG_REQUESTS', false);

  /// Whether a failure may include the stack trace in the log output.
  static bool get verboseErrors => _bool('VERBOSE_ERRORS', !isProduction);

  static bool _bool(String key, bool fallback) {
    final raw = (_env[key] ?? '').trim().toLowerCase();
    if (raw.isEmpty) return fallback;
    return raw == 'true' || raw == '1' || raw == 'yes' || raw == 'on';
  }

  // ---------------------------------------------------------------------
  // Database
  // ---------------------------------------------------------------------

  static String get dbHost => _env['DB_HOST'] ?? '127.0.0.1';
  static int get dbPort => int.tryParse(_env['DB_PORT'] ?? '') ?? 5432;
  static String get dbName => _env['DB_NAME'] ?? 'parkshare';
  static String get dbUser => _env['DB_USER'] ?? 'parkshare';
  static String get dbPassword => _env['DB_PASSWORD'] ?? '';

  /// HTTP port. Precedence: platform `PORT` env var (e.g. `$env:PORT=8081`),
  /// then `PORT` in backend/.env, then default 8080.
  static int get port =>
      int.tryParse(Platform.environment['PORT'] ?? '') ??
      int.tryParse(_env['PORT'] ?? '') ??
      8080;

  // ---------------------------------------------------------------------
  // JWT
  // ---------------------------------------------------------------------

  /// The HMAC signing key.
  ///
  /// In production there is NO fallback: a missing value yields an empty
  /// string, which [validateForStartup] rejects, so the process exits instead
  /// of running with a public key.
  static String get jwtSecret {
    final raw = (_env['JWT_SECRET'] ?? '').trim();
    if (raw.isNotEmpty) return raw;
    return isProduction ? '' : devJwtSecret;
  }

  static int get accessExpiryMinutes =>
      int.tryParse(_env['JWT_ACCESS_EXPIRES_MINUTES'] ?? '') ?? 60;
  static int get refreshTokenDays =>
      int.tryParse(_env['REFRESH_TOKEN_DAYS'] ?? '') ?? 30;

  // ---------------------------------------------------------------------
  // OTP / password reset
  // ---------------------------------------------------------------------

  static int get otpTtlMinutes =>
      int.tryParse(_env['OTP_TTL_MINUTES'] ?? '') ?? 10;

  /// How many wrong guesses an OTP tolerates before it is destroyed.
  static int get otpMaxAttempts =>
      int.tryParse(_env['OTP_MAX_ATTEMPTS'] ?? '') ?? 5;

  /// Minimum seconds between two OTPs for the same account.
  static int get otpResendCooldownSeconds =>
      int.tryParse(_env['OTP_RESEND_COOLDOWN_SECONDS'] ?? '') ?? 60;

  /// Minimum length of a new password.
  static int get minPasswordLength =>
      int.tryParse(_env['MIN_PASSWORD_LENGTH'] ?? '') ?? 8;

  /// Per-IP request budget for the unauthenticated auth endpoints, per
  /// minute. `0` disables the limiter (development only).
  static int get authRateLimitPerMinute =>
      int.tryParse(_env['AUTH_RATE_LIMIT_PER_MINUTE'] ?? '') ?? 30;

  /// Maximum number of OTP verifications a single IP may attempt per minute.
  static int get otpRateLimitPerMinute =>
      int.tryParse(_env['OTP_RATE_LIMIT_PER_MINUTE'] ?? '') ?? 20;

  // ---------------------------------------------------------------------
  // Mail (password-reset delivery)
  // ---------------------------------------------------------------------

  static String get smtpHost => _env['SMTP_HOST'] ?? '';
  static int get smtpPort => int.tryParse(_env['SMTP_PORT'] ?? '') ?? 587;
  static String get smtpUser => _env['SMTP_USER'] ?? '';
  static String get smtpPassword => _env['SMTP_PASSWORD'] ?? '';
  static String get smtpFrom => _env['SMTP_FROM'] ?? 'noreply@parkshare.com';

  /// True when an SMTP server was configured.
  static bool get smtpConfigured => smtpHost.trim().isNotEmpty;

  /// AUDIT H-02: the OTP may only be printed / returned when BOTH of these
  /// hold. It can never be enabled in production, so a production deploy can
  /// not leak a password-reset code through the API or the logs.
  static bool get allowDevOtp =>
      !isProduction && _bool('ALLOW_DEV_OTP', false) && !smtpConfigured;

  // ---------------------------------------------------------------------
  // CORS
  // ---------------------------------------------------------------------

  /// `CORS_ALLOWED_ORIGINS` — comma separated. Empty means "reflect nothing",
  /// and [allowedOrigins] then falls back to `*` in development only.
  static List<String> get corsAllowedOrigins {
    final raw = _env['CORS_ALLOWED_ORIGINS'] ?? '';
    return raw
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList(growable: false);
  }

  /// The `Access-Control-Allow-Origin` values this server will ever send.
  static Set<String> get effectiveAllowedOrigins {
    final configured = corsAllowedOrigins;
    if (configured.isNotEmpty) return configured.toSet();
    if (isProduction) return const <String>{};
    return const <String>{'*'};
  }

  // ---------------------------------------------------------------------
  // Uploads / media storage
  // ---------------------------------------------------------------------

  /// Directory where owner parking photos are stored on disk. Never store
  /// absolute local device paths in PostgreSQL — the DB keeps public URLs.
  static String get uploadDir => _env['UPLOAD_DIR'] ?? 'uploads';
  static int get maxUploadBytes =>
      int.tryParse(_env['MAX_UPLOAD_BYTES'] ?? '') ?? (8 * 1024 * 1024);

  /// Public base URL for uploaded files, e.g. "https://api.parkshare.in".
  ///
  /// When empty the backend derives it from each request's Host header so the
  /// stored URL works for the Android emulator (10.0.2.2) and iOS simulator
  /// (localhost) during development. Production MUST set it — otherwise a
  /// caller can poison stored photo URLs with a spoofed `Host` header
  /// (audit M-03).
  static String get publicBaseUrl => (_env['PUBLIC_BASE_URL'] ?? '').trim();

  // ---------------------------------------------------------------------
  // Startup validation
  // ---------------------------------------------------------------------

  /// Returns a list of human-readable configuration problems. An empty list
  /// means the process may start. Called by `bin/server.dart` before the
  /// socket is bound so a misconfigured production deploy fails loudly
  /// instead of silently running insecurely.
  ///
  /// No secret value is ever included in the returned messages.
  static List<String> validateForStartup() {
    final problems = <String>[];

    final secret = jwtSecret;
    if (secret.isEmpty) {
      problems.add(
        'JWT_SECRET is not set. Add a random value of at least '
        '$minJwtSecretLength characters to backend/.env (or the process '
        'environment).',
      );
    } else if (isProduction) {
      if (secret == devJwtSecret) {
        problems.add(
          'JWT_SECRET is still the published development placeholder. '
          'Generate a unique secret, e.g. with: '
          r'$env:JWT_SECRET = [Convert]::ToBase64String('
          '[System.Security.Cryptography.RandomNumberGenerator]::GetBytes(48))',
        );
      } else if (secret.length < minJwtSecretLength) {
        problems.add(
          'JWT_SECRET is too short: $minJwtSecretLength characters minimum.',
        );
      }
    }

    if (!smtpConfigured && !allowDevOtp) {
      problems.add(
        'No SMTP server is configured (SMTP_HOST) and ALLOW_DEV_OTP is not '
        'true, so password-reset OTPs cannot be delivered. Configure SMTP, '
        'or set ALLOW_DEV_OTP=true for a development-only run.',
      );
    }

    if (publicBaseUrl.isEmpty && isProduction) {
      problems.add(
        'PUBLIC_BASE_URL must be set in production so uploaded photo URLs '
        'cannot be poisoned through a spoofed Host header.',
      );
    }

    if (isProduction && effectiveAllowedOrigins.isEmpty) {
      problems.add(
        'CORS_ALLOWED_ORIGINS must list the origins allowed to call the API '
        'in production (comma separated).',
      );
    }

    return problems;
  }

  static void load() {
    // Ensures Config is initialized (dotenv loaded) by touching properties.
    // NEVER prints a secret: only non-sensitive settings and booleans.
    print(
      'Config loaded: appEnv=$appEnv db=${dbHost}:${dbPort}/${dbName} '
      'port=$port smtp=${smtpConfigured ? 'enabled' : 'disabled'} '
      'devOtp=${allowDevOtp ? 'enabled' : 'disabled'} '
      'uploads=${uploadDir} maxBytes=$maxUploadBytes '
      'corsOrigins=${effectiveAllowedOrigins.join(",")}',
    );
  }
}
