import 'package:parkshare_backend/config/config.dart';
import 'package:parkshare_backend/middleware/auth_middleware.dart';
import 'package:parkshare_backend/middleware/middleware.dart';
import 'package:parkshare_backend/services/auth_service.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

/// Authentication routes:
///   POST /api/auth/register
///   POST /api/auth/login
///   POST /api/auth/refresh
///   GET  /api/auth/me
///   POST /api/auth/logout
///   POST /api/auth/forgot-password
///   POST /api/auth/verify-reset-otp
///   POST /api/auth/reset-password
///
/// SECURITY (audit H-05): every credential-touching route is wrapped in
/// [rateLimitMiddleware]. Before this, an unauthenticated caller could grind a
/// 6-digit OTP against `/verify-reset-otp` and a password list against
/// `/login` at line speed. Two separate budgets are used because a legitimate
/// user walking the reset flow (forgot -> verify -> reset) must never be locked
/// out by an attacker exhausting the OTP budget, and vice versa.
class AuthRoutes {
  final AuthService _service = AuthService();

  Handler get handler {
    final router = Router(
      notFoundHandler: (Request req) {
        return ApiResponse.notFound('Auth route not found.');
      },
    );

    // Credential endpoints: the tighter budget, keyed per client address.
    final credentialLimit = rateLimitMiddleware(
      requestsPerMinute: Config.authRateLimitPerMinute,
      name: 'auth',
    );
    // OTP endpoints: their own budget so reset attempts cannot be used to
    // lock a user out of logging in, and vice versa.
    final otpLimit = rateLimitMiddleware(
      requestsPerMinute: Config.otpRateLimitPerMinute,
      name: 'otp',
    );

    router.post(
      '/register',
      credentialLimit((Request req) async {
        final body = await readJsonBody(req) ?? {};
        final payload = await _service.register(
          name: body['name']?.toString() ?? '',
          email: body['email']?.toString() ?? '',
          phone: body['phone']?.toString() ?? '',
          upiId: body['upiId']?.toString(),
          password: body['password']?.toString() ?? '',
          confirmPassword: body['confirmPassword']?.toString(),
          role: body['role']?.toString() ?? '',
        );
        return ApiResponse.created(
          payload.toJson(),
          'Account created successfully.',
        );
      }),
    );

    router.post(
      '/login',
      credentialLimit((Request req) async {
        final body = await readJsonBody(req) ?? {};
        final payload = await _service.login(
          email: body['email']?.toString() ?? '',
          password: body['password']?.toString() ?? '',
          role: body['role']?.toString(),
        );
        return ApiResponse.ok(payload.toJson(), 'Login successful.');
      }),
    );

    router.post('/refresh', (Request req) async {
      final body = await readJsonBody(req) ?? {};
      final payload = await _service.refresh(
        body['refreshToken']?.toString() ?? '',
      );
      return ApiResponse.ok(payload.toJson(), 'Session refreshed.');
    });

    router.get(
      '/me',
      authMiddleware()((Request req) async {
        final payload = await _service.me(userIdOf(req));
        return ApiResponse.ok(payload.toJson(), 'User loaded.');
      }),
    );

    router.post('/logout', (Request req) async {
      final body = await readJsonBody(req) ?? {};
      await _service.logout(body['refreshToken']?.toString() ?? '');
      return ApiResponse.ok(null, 'Logged out successfully.');
    });

    router.post(
      '/forgot-password',
      otpLimit((Request req) async {
        final body = await readJsonBody(req) ?? {};
        final result = await _service.forgotPassword(
          body['email']?.toString() ?? '',
          clientIp: clientIpOf(req),
        );
        // The response body and the status code are identical whether or not
        // the address is registered (audit H-03). `kForgotPasswordResponse` is
        // the single shared wording so the two cases cannot be told apart from
        // either the message, the shape or the timing.
        return ApiResponse.ok(result, kForgotPasswordResponse);
      }),
    );

    router.post(
      '/verify-reset-otp',
      otpLimit((Request req) async {
        final body = await readJsonBody(req) ?? {};
        await _service.verifyResetOtp(
          body['email']?.toString() ?? '',
          body['otp']?.toString() ?? '',
        );
        return ApiResponse.ok(null, 'OTP verified.');
      }),
    );

    router.post(
      '/reset-password',
      otpLimit((Request req) async {
        final body = await readJsonBody(req) ?? {};
        await _service.resetPassword(
          email: body['email']?.toString() ?? '',
          otp: body['otp']?.toString() ?? '',
          newPassword: body['newPassword']?.toString() ?? '',
        );
        return ApiResponse.ok(
          null,
          'Password reset successfully. You can now login.',
        );
      }),
    );

    return router.call;
  }
}
