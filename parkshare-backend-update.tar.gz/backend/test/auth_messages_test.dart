// Regression tests for audit H-03 (password-reset account enumeration).
//
// `POST /api/auth/forgot-password` used to answer
//   "No account found for this email address."
// which turned the endpoint into a free account-enumeration oracle. The fix is
// a single unconditional response for every address. These tests lock the
// wording down so a future edit cannot quietly reintroduce the oracle.
import 'package:parkshare_backend/services/auth_service.dart';
import 'package:test/test.dart';

/// Phrases that let an attacker distinguish "no such account" from "reset
/// email sent". None of these may appear in a response.
const List<String> kEnumerationMarkers = [
  'not found',
  'no account',
  'no such account',
  'no such user',
  'no user',
  'does not exist',
  "doesn't exist",
  'unknown email',
  'unknown user',
  'is not registered',
  'not registered',
  'unregistered',
  'invalid email',
  'no such',
  'try another',
  'try a different',
  'already registered',
  'email already',
];

void main() {
  group('kForgotPasswordResponse', () {
    test('leaks nothing about whether the address exists', () {
      final text = kForgotPasswordResponse.toLowerCase();
      for (final marker in kEnumerationMarkers) {
        expect(
          text,
          isNot(contains(marker)),
          reason: 'enumeration marker "$marker" must not appear',
        );
      }
    });

    test('is phrased conditionally so both branches read the same', () {
      expect(kForgotPasswordResponse.toLowerCase(), contains('if an account exists'));
    });

    test('tells the user what to do next', () {
      expect(kForgotPasswordResponse.toLowerCase(), contains('check your inbox'));
    });
  });

  group('kInvalidOtpMessage', () {
    test('leaks nothing about the address or the account', () {
      final text = kInvalidOtpMessage.toLowerCase();
      for (final marker in kEnumerationMarkers) {
        expect(
          text,
          isNot(contains(marker)),
          reason: 'enumeration marker "$marker" must not appear',
        );
      }
    });

    test('covers wrong code AND unknown email with one message', () {
      expect(kInvalidOtpMessage.toLowerCase(), contains('invalid or expired'));
      // It must not tell the client WHICH of the two happened.
      expect(kInvalidOtpMessage.toLowerCase(), isNot(contains('wrong code')));
      expect(
        kInvalidOtpMessage.toLowerCase(),
        isNot(contains('code has expired')),
      );
    });
  });

  group('the two messages are mutually distinct', () {
    test('a wrong OTP and an unknown email cannot be told apart', () {
      expect(kInvalidOtpMessage, isNot(kForgotPasswordResponse));
    });
  });
}
